import { test, expect, request } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

let testDocumentId: string;

test.beforeAll(async ({ playwright }) => {
  // Inherits baseURL (http://localhost:4173) from playwright.config.ts
  const apiContext = await playwright.request.newContext();

  // Minimal valid 1-page PDF buffer containing "Test Document for Accessibility"
  const pdfBuffer = Buffer.from(
    'JVBERi0xLjQKJeLjz9MKMyAwIG9iago8PC9UeXBlL1BhZ2UvUGFyZW50IDIgMCBSL1Jlc291cmNlczw8L0ZvbnQ8PC9GMSA1IDAgUj4+Pj4vTWVkaWFCb3hbMCAwIDYxMiA3OTJdL0NvbnRlbnRzIDQgMCBSPj4KZW5kb2JqCjQgMCBvYmoKPDwvTGVuZ3RoIDY1Pj4Kc3RyZWFtCkJUCi9GMSA4IFRmCjEwMCA3MDAgVGQKKFRlc3QgRG9jdW1lbnQgZm9yIEFjY2Vzc2liaWxpdHkpIFRqCkVUCmVuZHN0cmVhbQplbmRvYmoKMiAwIG9iago8PC9UeXBlL1BhZ2VzL0NvdW50IDEvS2lkc1szIDAgUl0+PgplbmRvYmoKMSAwIG9iago8PC9UeXBlL0NhdGFsb2cvUGFnZXMgMiAwIFI+PgplbmRvYmoKNSAwIG9iago8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMS9CYXNlRm9udC9IZWx2ZXRpY2E+PgplbmRvYmoKeHJlZgowIDYKMDAwMDAwMDAwMCA2NTUzNSBmDQowMDAwMDAwMjc5IDAwMDAwIG4NCjAwMDAwMDAyMjggMDAwMDAgbg0KMDAwMDAwMDAxNSAwMDAwMCBuDQowMDAwMDAwMTI0IDAwMDAwIG4NCjAwMDAwMDAzMjggMDAwMDAgbg0KdHJhaWxlcgo8PC9TaXplIDYvUm9vdCAxIDAgUj4+CnN0YXJ0eHJlZgo0MDUKJSVFT0Y=',
    'base64'
  );

  const form = new FormData();
  form.append('file', new Blob([pdfBuffer], { type: 'application/pdf' }), 'test-doc.pdf');

  const response = await apiContext.post('/api/documents/upload', {
    multipart: form,
  });

  if (!response.ok()) {
    const text = await response.text();
    throw new Error(`Failed to seed test document: ${response.status()} ${text}`);
  }

  const data = await response.json();
  // Adjust 'id' if your API returns it nested (e.g., data.document.id)
  testDocumentId = data.id || data.document?.id;
  
  if (!testDocumentId) {
    throw new Error(`Could not extract document ID from upload response: ${JSON.stringify(data)}`);
  }
  
  console.log(`✅ Seeded test document with ID: ${testDocumentId}`);
});

test.describe('WCAG 2.2 AA accessibility checks', () => {
  test('1. document view has zero axe violations', async ({ page }) => {
    await page.goto(`/documents/${testDocumentId}`);
    await page.waitForLoadState('networkidle');
    await page.waitForSelector('main, [role="main"]', { state: 'visible' });

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'])
      .analyze();

    if (results.violations.length > 0) {
      console.error('Axe Violations:', JSON.stringify(results.violations, null, 2));
    }
    expect(results.violations).toEqual([]);
  });

  test('2. ask-the-document view has zero axe violations', async ({ page }) => {
    await page.goto(`/documents/${testDocumentId}`);
    await page.waitForLoadState('networkidle');
    await page.waitForSelector('.cc-question-panel, [aria-label*="ask" i], [data-testid*="ask" i]', { state: 'visible', timeout: 10000 }).catch(() => {});

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'])
      .analyze();

    if (results.violations.length > 0) {
      console.error('Axe Violations:', JSON.stringify(results.violations, null, 2));
    }
    expect(results.violations).toEqual([]);
  });

  test('3. version diff view has zero axe violations', async ({ page }) => {
    await page.goto(`/documents/${testDocumentId}/compare`);
    await page.waitForLoadState('networkidle');
    await page.waitForSelector('main, [role="main"]', { state: 'visible' });

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'])
      .analyze();

    if (results.violations.length > 0) {
      console.error('Axe Violations:', JSON.stringify(results.violations, null, 2));
    }
    expect(results.violations).toEqual([]);
  });

  test('4. base accessibility page has zero axe violations', async ({ page }) => {
    await page.goto('/accessibility');
    await page.waitForLoadState('networkidle');

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'])
      .analyze();

    expect(results.violations).toEqual([]);
  });

  test('5. skip link focuses main content', async ({ page }) => {
    await page.goto(`/documents/${testDocumentId}`);
    await page.waitForLoadState('networkidle');
    await page.keyboard.press('Tab');
    const skipLink = page.locator('.skip-link');
    await expect(skipLink).toBeFocused();
    await page.keyboard.press('Enter');
    const main = page.locator('#main-content, main');
    await expect(main).toBeFocused();
  });

  test('6. severity badges include explicit text and icon', async ({ page }) => {
    await page.goto(`/documents/${testDocumentId}`);
    await page.waitForLoadState('networkidle');
    await page.waitForSelector('[role="status"]', { state: 'visible', timeout: 10000 }).catch(() => {});
    
    const badge = page.locator('[role="status"]').first();
    await expect(badge).toBeVisible();
    
    const icon = badge.locator('svg');
    await expect(icon).toBeVisible();
    
    const text = badge.locator('span').first();
    await expect(text).toBeVisible();
  });

  test('7. accessible form announces and focuses validation errors', async ({ page }) => {
    await page.goto('/accessibility');
    await page.waitForLoadState('networkidle');
    const submitBtn = page.getByRole('button', { name: /submit/i });
    await submitBtn.click();
    const errorSummary = page.getByRole('alert');
    await expect(errorSummary).toBeFocused();
  });
});

